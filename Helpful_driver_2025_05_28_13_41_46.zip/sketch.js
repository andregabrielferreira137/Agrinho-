let player;

let obstacles = [];

let score = 0;

let gameOver = false;

function setup() {

  createCanvas(600, 400);

  player = new Player();

}

function draw() {

  background(30);

  if (!gameOver) {

    player.show();

    player.move();

    if (frameCount % 60 == 0) {

      obstacles.push(new Obstacle());

    }

    for (let obs of obstacles) {

      obs.move();

      obs.show();

      if (obs.hits(player)) {

        gameOver = true;

      }

    }

    obstacles = obstacles.filter(obs => obs.y < height + obs.size);

    fill(255);

    textSize(20);

    text('Score: ' + score, 10, 30);

    score++;

  } else {

    fill(255, 0, 0);

    textSize(40);

    textAlign(CENTER);

    text('Game Over', width / 2, height / 2);

    textSize(20);

    text('Score: ' + score, width / 2, height / 2 + 40);

  }

}

class Player {

  constructor() {

    this.size = 40;

    this.x = width / 2 - this.size / 2;

    this.y = height - this.size - 10;

    this.speed = 5;

  }

  show() {

    fill(0, 255, 0);

    rect(this.x, this.y, this.size, this.size);

  }

  move() {

    if (keyIsDown(LEFT_ARROW) && this.x > 0) {

      this.x -= this.speed;

    }

    if (keyIsDown(RIGHT_ARROW) && this.x < width - this.size) {

      this.x += this.speed;

    }

  }

}

class Obstacle {

  constructor() {

    this.size = random(20, 50);

    this.x = random(0, width - this.size);

    this.y = -this.size;

    this.speed = 4 + score / 100;

  }

  show() {

    fill(255, 0, 0);

    rect(this.x, this.y, this.size, this.size);

  }

  move() {

    this.y += this.speed;

  }

  hits(player) {

    return (

      player.x < this.x + this.size &&

      player.x + player.size > this.x &&

      player.y < this.y + this.size &&

      player.y + player.size > this.y

    );

  }

}